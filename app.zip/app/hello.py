# import json
#
# def welcome(event, context):
#     print("Hello from Lambda!")
#     return {
#         'statusCode': 200,
#         'body': json.dumps('Hello from Lambda!')
#     }


def welcome():
    print("hi")